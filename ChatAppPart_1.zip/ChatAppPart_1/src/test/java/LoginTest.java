/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */

import com.mycompany.chatapppart_1.Login; 
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author Student
 */

  public class LoginTest { 
      //Login object so we can test its method 
      Login login = new Login();
      
      @Test 
      public void testValidUsername(){ 
          //Testing if the username has underscore and is no more than five characters
          assertTrue(login.checkUserName("kyl_")); 
      }
      @Test 
      public void testInvalidUsername(){
          //Testing the username with no underscore and has more than five characters 
          assertFalse(login.checkUserName("kyle!!!!!!!")); 
      }
      
      @Test 
      public void testValidPasswordComplexity(){
          //Testing if it meets the complexity requirements 
          assertTrue(login.checkPasswordComplexity("Ch&&sec@ke99!")); 
      }
      @Test
      public void testInvalidPasswordComplexity(){
          //Checks if the password does not meet the complexity requirements
          assertFalse(login.checkPasswordComplexity("password")); 
      } 
      @Test 
      public void testValidCellphoneNumber(){ 
          //Checks if it contains international country code
          assertTrue(login.checkPhoneNumber("+27838968976")); 
      }
      @Test 
      public void testInvalidCellphoneNumber(){ 
          //Checks if it does not contain an international country code 
          assertFalse(login.checkPhoneNumber("08966553")); 
   
      }
        
    } 
 

