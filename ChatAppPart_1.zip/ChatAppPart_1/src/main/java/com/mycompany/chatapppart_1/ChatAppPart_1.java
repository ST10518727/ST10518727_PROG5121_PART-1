/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.chatapppart_1;

/**
 *
 * @author Student
 */
public class ChatAppPart_1 {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
