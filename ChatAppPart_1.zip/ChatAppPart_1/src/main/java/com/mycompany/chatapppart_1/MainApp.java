/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.chatapppart_1;

import java.util.Scanner; 

/**
 *
 * @author Student
 */
public class MainApp {
    public static void main(String[] args) { 
        //Scanner allows the user to enter information 
        Scanner input = new Scanner(System.in); 
        
        //Initialize the Login class to use its methods 
        Login login = new Login(); 
        
        //REGISTRATION SECTION 
        
        System.out.println("USER REGISTRATION"); 
        
        System.out.println("Enter a username: "); 
        String username = input.nextLine(); 
        
        System.out.print("Enter password: ");
        String password = input.nextLine(); 
        
        System.out.print("Enter your South African phone number (+27...): "); 
        String phoneNumber = input.nextLine(); 
        
        //CALL THE REGISTER USER METHOD AND STORE THE MESSAGE IT RETURNS 
        String response = login.registerUser(username, password, phoneNumber);
        
        //REGISTRATION MESSAGE 
        System.out.println(response); 
        
        //LOGIN SECTION
        System.out.println("USER LOGIN");
        
        System.out.print("Enter your username: ");
        String loginUsername = input.nextLine(); 
        
        System.out.print("Enter your password: ");
        String loginPassword = input.nextLine(); 
        
        //Call loginUser to check if the details match the hoarded ones
        boolean loggedIn = login.loginUser(loginUsername, loginPassword); 
        
        //Print out the correct login message 
        String loginMessage = login.returnLoginStatus(loggedIn); 
        System.out.println(loginMessage); 
        
    }
    
}
